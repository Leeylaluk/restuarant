import { BrowserRouter, Routes, Route } from "react-router-dom"
import Home from "./Pages/Home"
import Restaurant from "./Pages/Restaurant"
import Header from "./Components/Header"
import Footer from "./Components/Footer"

function App() {
  return (
    <BrowserRouter>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/restaurant" element={<Restaurant />} />
      </Routes>
      <Footer />
    </BrowserRouter>
  )
}

export default App