import FoodCard from "../Components/FoodCard"

export default function Restaurant() {
  const foods = [
    {
      title: "Пицца Везувий",
      description: "Соус томатный, сыр «Моцарелла», ветчина, пепперони, перец «Халапенье», соус «Тобаско», томаты.",
      price: "545 ₽",
      image: "/img/pizza-plus/pizza-vesuvius.jpg"
    },
    {
      title: "Пицца Девичник",
      description: "Соус томатный, постное тесто, нежирный сыр, кукуруза, лук, маслины, грибы, помидоры, болгарский перец.",
      price: "450 ₽",
      image: "/img/pizza-plus/pizza-girls.jpg"
    },
    {
      title: "Пицца Оле-Оле",
      description: "Соус томатный, сыр «Моцарелла», черри, маслины, зелень, майонез",
      price: "440 ₽",
      image: "/img/pizza-plus/pizza-oleole.jpg"
    },
    {
      title: "Пицца Плюс",
      description: "Соус томатный, сыр «Моцарелла», сыр «Чеддер», томаты, пепперони, телятина, грибы, бекон, болгарский перец.",
      price: "805 ₽",
      image: "/img/pizza-plus/pizza-plus.jpg"
    },
    {
      title: "Пицца Гавайская",
      description: "Соус томатный, сыр «Моцарелла», ветчина, ананасы",
      price: "440 ₽",
      image: "/img/pizza-plus/pizza-hawaiian.jpg"
    },
    {
      title: "Пицца Классика",
      description: "Соус томатный, сыр «Моцарелла», сыр «Пармезан», ветчина, салями, грибы.",
      price: "510 ₽",
      image: "/img/pizza-plus/pizza-classic.jpg"
    }
  ]

  return (
    <main className="main">
      <div className="container">
        <section className="menu">
          <div className="section-heading">
            <h2 className="section-title restaurant-title">Пицца Плюс</h2>
            <div className="card-info">
              <div className="rating">4.5</div>
              <div className="price">От 900 ₽</div>
              <div className="category">Пицца</div>
            </div>
          </div>
          <div className="cards cards-menu">
            {foods.map((food, i) => (
              <FoodCard
                key={i}
                title={food.title}
                description={food.description}
                price={food.price}
                image={food.image}
              />
            ))}
          </div>
        </section>
      </div>
    </main>
  )
}