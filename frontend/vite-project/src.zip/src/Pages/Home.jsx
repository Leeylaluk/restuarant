import RestaurantCard from "../Components/RestaurantCard"
import { Promo } from "../Components/Promo"
import "../styles/style.css"
import "../styles/normalize.css"

export default function Home() {
  const restaurants = [
    {
      title: "Пицца плюс",
      image: "/img/pizza-plus/preview.jpg",
      time: "50 мин",
      rate: "4.5",
      price: "От 900 ₽",
      category: "Пицца"
    },
    {
      title: "Тануки",
      image: "/img/tanuki/preview.jpg",
      time: "60 мин",
      rate: "4.5",
      price: "От 1 200 ₽",
      category: "Суши, роллы"
    },
    {
      title: "FoodBand",
      image: "/img/food-band/preview.jpg",
      time: "40 мин",
      rate: "4.5",
      price: "От 450 ₽",
      category: "Пицца"
    },
    {
      title: "Палки скалки",
      image: "/img/palki-skalki/preview.jpg",
      time: "55 мин",
      rate: "4.5",
      price: "От 500 ₽",
      category: "Пицца"
    },
    {
      title: "Гуси Лебеди",
      image: "/img/gusi-lebedi/preview.jpg",
      time: "75 мин",
      rate: "4.5",
      price: "От 1 000 ₽",
      category: "Русская кухня"
    },
    {
      title: "PizzaBurger",
      image: "/img/pizza-burger/preview.jpg",
      time: "45 мин",
      rate: "4.5",
      price: "От 700 ₽",
      category: "Пицца"
    }
  ]

  return (
    <main className="main">
      <div className="container">
        <Promo />
        <section className="restaurants">
          <div className="section-heading">
            <h2 className="section-title">Рестораны</h2>
            <label className="search">
              <input type="text" className="input input-search" placeholder="Поиск блюд и ресторанов" />
            </label>
          </div>
          <div className="cards cards-restaurants">
            {restaurants.map((r, i) => (
              <RestaurantCard
                key={i}
                title={r.title}
                image={r.image}
                time={r.time}
                rate={r.rate}
                price={r.price}
                category={r.category}
              />
            ))}
          </div>
        </section>
      </div>
    </main>
  )
}